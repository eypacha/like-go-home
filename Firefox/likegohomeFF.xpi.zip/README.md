The idea of ​​this Add-On is to stop using the facebook like as something as normal and get to think about what it means. Also start communicating with people a little more with words. 

"I really like this post"
"Great Job"
"Nice cat" (don't abuse of this one)

We recommend using it a while and leave us your feedback in https://www.facebook.com/pages/Like-go-home/1467697393460827